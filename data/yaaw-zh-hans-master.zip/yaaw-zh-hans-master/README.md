YAAW-zh-Hans
----

汉化过的 [YAAW](https://github.com/binux/yaaw) 并修复了一些小BUG

访问地址 [aria2c.com](http://aria2c.com/)

latest commit 3a3ff668a9b304dffde9fce5b1c7665d40674291
