#!/bin/sh
VER="1.0.3"
echo "===============easyRouter Toolbox LocalPackage V$VER==============="
killall aria2c > /dev/null 2>&1
/etc/init.d/easyRouter stop > /dev/null 2>&1
sleep 1
killall node
ISTEST=0
PKG="arm"
echo "Checking Hardware..."
Hardware_ID=$(uname -a | grep arm | wc -l)
if [ "$Hardware_ID" = '0' ]; then
	if [ $(uname -a | awk '{print $4;}' | sed 's/'#'//') = '2' ]; then
		PKG="mips"
		echo "Error:This Version does NOT support R1CM"
		exit
	fi
	if [ $(uname -a | awk '{print $4;}' | sed 's/'#'//') = '3' ]; then
	PKG="mips"
		echo "Error:This Version does NOT support R3"
		exit
	fi
	if [ $(uname -a | grep MINGW | wc -l) = '1' ]; then
		PKG="windows"
		echo "You're using MINGW testing environment."
		ISTEST=1
	fi
	if [ -d "/mnt/c/Users/" ] ; then
		echo "You're using win10Bash testing environment."
		ISTEST=1
	fi
fi
#rm /tmp/easyRouter.tgz
#URL="http://c2.e123.pw/miwifi/easyRouter/"${VER}"/"${PKG}"/easyRouter.tgz"
#URL="http://cdn.fds.api.xiaomi.com/b2c-bbs/cn/attachment/bead5ad10fc09b37c08ee98a1ff33811.zip"
#wget ${URL} -c -O /tmp/easyRouter.tgz
#if [ "$?" != "0" ]; then
#    echo "Error:DownLoad installnation package Failed"
#    exit
#fi
tar -zxvf /tmp/easyRouter.tgz -C /userdisk/data
if [ "$?" != "0" ]; then
    echo "Error:tar -zxvf failed"
    exit
fi
echo "Making binaries excutable"
chmod -R 777 /userdisk/data/.easyRouter/
if [ ! -d "/userdisk/data/.easyRouter/" ] ; then
    echo "Install faild."
    exit
fi
echo "Adding toolbox to /etc/init.d"
cp /userdisk/data/.easyRouter/_Bin/easyRouter.init /etc/init.d/easyRouter
chmod +x /etc/init.d/easyRouter
/etc/init.d/easyRouter enable
/etc/init.d/easyRouter start
echo "===============easyRouter Toolbox==============="
echo "Installation complete."
echo "Please visit http://router.e123.pw/ to manage the toolbox."